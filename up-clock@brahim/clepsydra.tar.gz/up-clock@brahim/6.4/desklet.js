// Clepsydra — Cinnamon Desklet  v5
// Brahim Salem
//
// Features:
//   • Chameleon background (macOS Monterey/Sonoma palette, smooth lerp)
//   • Rainbow bubbles toggle — each bubble cycles its own colour
//   • Frosted-glass bubbles toggle — macOS liquid-glass look (radial gradient + specular)
//   • Magic mode — bubbles escape the circle and fade with distance
//   • St.Bin centering — clock text always centred regardless of chameleon repaints
//   • Resize debounce — no Cinnamon freeze while dragging the size slider

const St            = imports.gi.St;
const Clutter       = imports.gi.Clutter;
const Cairo         = imports.cairo;
const GLib          = imports.gi.GLib;
const Gio           = imports.gi.Gio;
const Desklet       = imports.ui.desklet;
const Settings      = imports.ui.settings;
const SignalManager = imports.misc.signalManager;

const { timeout_add, source_remove, remove_all_sources } = require("./mainloopTools");

const UUID        = "up-clock@brahim";
const DESKLET_DIR = imports.ui.deskletManager.deskletMeta[UUID].path;

const MACOS_PALETTE = [
    "#0071e3","#30b15f","#ff375f","#ff9500","#ffcc00",
    "#5e5ce6","#bf5af2","#32ade6","#ff6961","#30d158",
    "#2ac4b4","#ff453a","#ff9f0a","#636366","#1c1c1e","#f2f2f7"
];

// Ubuntu Touch screensaver palette — purples, magentas, deep pinks
const UBUNTU_TOUCH_PALETTE = [
    "#9b59b6","#8e44ad","#e056fd","#fd79a8",
    "#a855f7","#c084fc","#e879f9","#f0abfc",
    "#be185d","#d946ef","#7c3aed","#6d28d9"
];
const UT_BUBBLE_COUNT  = 22;
const UT_BUBBLE_MIN_R  = 22;
const UT_BUBBLE_MAX_R  = 82;

const CLASSIC_COLOR    = "#2f0916";
const BUBBLE_COUNT     = 26;
const BUBBLE_MIN_R     = 18;
const BUBBLE_MAX_R     = 55;
const BUBBLE_ALPHA_MAX = 0.42;
const DOT_COUNT        = 60;
const DOT_R            = 2.5;
const RING_PAD         = 8;
// How far above the desklet a magic bubble travels before resetting (in px)
const MAGIC_FADE_DIST  = 220;

// ── Colour helpers ────────────────────────────────────────────────────────────
function hexToRGB(hex) {
    if (!hex) return [0, 0, 0];
    // Handle rgba(r,g,b,a) or rgb(r,g,b) — returned by Cinnamon colorchooser
    const rgba = hex.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
    if (rgba) return [parseInt(rgba[1])/255, parseInt(rgba[2])/255, parseInt(rgba[3])/255];
    hex = hex.replace(/^#/, "");
    if (hex.length === 3) hex = hex.split("").map(c => c+c).join("");
    const n = parseInt(hex, 16) || 0;
    return [(n>>16&255)/255, (n>>8&255)/255, (n&255)/255];
}
function tintRGB(rgb, f)  { return rgb.map(c => Math.min(1, c + (1-c)*f)); }
function lerpHex(a, b, t) {
    const ra = hexToRGB(a), rb = hexToRGB(b);
    return "#" + ra.map((v,i) =>
        Math.round((v + (rb[i]-v)*t)*255).toString(16).padStart(2,"0")).join("");
}
function clipCircle(cr, w, h) {
    cr.arc(w/2, h/2, Math.min(w,h)/2, 0, 2*Math.PI);
    cr.clip();
    cr.newPath();
}

// ── Bubble ────────────────────────────────────────────────────────────────────
function Bubble(size, index) {
    this._index = index;
    this.reset(size);
}
Bubble.prototype = {
    reset: function(size) {
        this.r       = BUBBLE_MIN_R + Math.random()*(BUBBLE_MAX_R - BUBBLE_MIN_R);
        this.x       = Math.random() * size;
        this.y       = size + this.r + Math.random() * size;
        this.vx      = (Math.random() - 0.5) * 0.6;
        this.vy      = -(0.4 + Math.random() * 0.7);
        this.alpha   = 0.10 + Math.random() * BUBBLE_ALPHA_MAX;
        this.phase   = Math.random() * Math.PI * 2;
        this.wobble  = 0.3 + Math.random() * 0.5;
        // Per-bubble rainbow state — stagger starting positions in palette
        this.hueT    = (this._index / BUBBLE_COUNT) % 1;
        this.hueIdx  = Math.floor(this.hueT * MACOS_PALETTE.length) % MACOS_PALETTE.length;
        this.huePhase = Math.random();
    },
    tick: function(size, dt, magic) {
        this.x += this.vx + Math.sin(this.phase) * this.wobble * dt;
        this.y += this.vy * dt;
        this.phase   += 0.03  * dt;
        this.huePhase += 0.004 * dt;   // colour cycles slowly
        if (this.huePhase >= 1) { this.huePhase = 0; this.hueIdx = (this.hueIdx + 1) % MACOS_PALETTE.length; }
        const limit = magic ? -(MAGIC_FADE_DIST + this.r + 10) : (-this.r - 10);
        if (this.y < limit) this.reset(size);
    },
    // Current rainbow colour for this bubble
    rainbowRGB: function() {
        const a = MACOS_PALETTE[this.hueIdx];
        const b = MACOS_PALETTE[(this.hueIdx + 1) % MACOS_PALETTE.length];
        return hexToRGB(lerpHex(a, b, this.huePhase));
    },
    // Alpha fade for magic mode (1.0 inside desklet → 0.0 at MAGIC_FADE_DIST above)
    magicFade: function() {
        if (this.y >= 0) return 1;
        const dist = -this.y;
        return Math.max(0, 1 - dist / MAGIC_FADE_DIST);
    }
};

// ── Ubuntu Touch radial bubble ───────────────────────────────────────────────
// Spawns near centre, travels outward in random direction, grows, fades at edge.
function UTBubble(size, index) { this._index = index; this.resetRadial(size); }
UTBubble.prototype = {
    resetRadial: function(size) {
        const ang  = Math.random() * Math.PI * 2;
        const dist = Math.random() * size * 0.18;
        this.x       = size/2 + Math.cos(ang)*dist;
        this.y       = size/2 + Math.sin(ang)*dist;
        this.angle   = Math.random() * Math.PI * 2;
        this.speed   = 0.35 + Math.random() * 0.55;
        this.vx      = Math.cos(this.angle) * this.speed;
        this.vy      = Math.sin(this.angle) * this.speed;
        this.r       = UT_BUBBLE_MIN_R * (0.4 + Math.random()*0.4);
        this.maxR    = UT_BUBBLE_MIN_R + Math.random()*(UT_BUBBLE_MAX_R - UT_BUBBLE_MIN_R);
        this.alpha   = 0.55 + Math.random()*0.35;
        this.life    = 0;
        this.lifeSpd = 0.003 + Math.random()*0.004;
        this.hueIdx  = (this._index + Math.floor(Math.random()*3)) % UBUNTU_TOUCH_PALETTE.length;
        this.huePhase = Math.random();
        this.hueSpd   = 0.002 + Math.random()*0.003;
    },
    tick: function(size, dt) {
        this.x    += this.vx * dt;
        this.y    += this.vy * dt;
        this.life += this.lifeSpd * dt;
        this.r     = Math.min(this.maxR, this.r + 0.18*dt);
        this.huePhase += this.hueSpd * dt;
        if (this.huePhase >= 1) { this.huePhase=0; this.hueIdx=(this.hueIdx+1)%UBUNTU_TOUCH_PALETTE.length; }
        if (this.life >= 1) this.resetRadial(size);
    },
    fadeAlpha: function() { return this.alpha * Math.sin(this.life * Math.PI); },
    colour: function() {
        const a = UBUNTU_TOUCH_PALETTE[this.hueIdx];
        const b = UBUNTU_TOUCH_PALETTE[(this.hueIdx+1) % UBUNTU_TOUCH_PALETTE.length];
        return hexToRGB(lerpHex(a, b, this.huePhase));
    }
};

// ── Desklet ───────────────────────────────────────────────────────────────────
function ClepsydraDesklet(metadata, instanceId) { this._init(metadata, instanceId); }

ClepsydraDesklet.prototype = {
    __proto__: Desklet.Desklet.prototype,

    _init: function(metadata, instanceId) {
        Desklet.Desklet.prototype._init.call(this, metadata, instanceId);
        this._signalManager = new SignalManager.SignalManager(null);

        this._settings = new Settings.DeskletSettings(this, UUID, instanceId);
        const B = Settings.BindingDirection.IN;

        this._settings.bindProperty(B,"use-24h",          "use24h",          () => this._updateClock(),        null);
        this._settings.bindProperty(B,"show-seconds",     "showSeconds",     () => this._updateClock(),        null);
        this._settings.bindProperty(B,"theme-color",      "themeColor",      () => this._onThemeChanged(),     null);
        this._settings.bindProperty(B,"opacity",          "clockOpacity",    () => this._updateRootOpacity(),  null);
        this._settings.bindProperty(B,"hide-decorations", "hideDecorations", () => this._applyDecorations(),   null);
        this._settings.bindProperty(B,"size",             "clockSize",       () => this._scheduleSizeChange(), null);
        this._settings.bindProperty(B,"font-family",      "fontFamily",      () => this._applyClockStyle(),    null);
        this._settings.bindProperty(B,"dot-color",        "dotColor",        () => this._invalidateRing(),     null);
        this._settings.bindProperty(B,"bubble-color",     "bubbleColor",     () => this._invalidateBg(),       null);
        this._settings.bindProperty(B,"chameleon-mode",   "chameleonMode",   () => this._onChameleonChanged(), null);
        this._settings.bindProperty(B,"rainbow-bubbles",  "rainbowBubbles",  () => this._invalidateBg(),       null);
        this._settings.bindProperty(B,"frosted-bubbles",  "frostedBubbles",  () => this._invalidateBg(),       null);
        this._settings.bindProperty(B,"magic-mode",       "magicMode",       () => this._onMagicChanged(),     null);
        this._settings.bindProperty(B,"ubuntu-touch-mode","ubuntuTouchMode",() => this._onUbuntuTouchChanged(),null);
        this._settings.bindProperty(B,"show-date",        "showDate",        () => this._updateDateLabel(),    null);
        this._settings.bindProperty(B,"date-font-family", "dateFontFamily",  () => this._updateDateLabel(),    null);
        this._settings.bindProperty(B,"clock-text-color", "clockTextColor",  () => this._applyClockStyle(),    null);
        this._settings.bindProperty(B,"date-text-color",  "dateTextColor",   () => this._updateDateLabel(),    null);

        this._bubbles          = [];
        this._timerRemaining   = 0;
        this._timerActive      = false;
        this._timerSource      = null;
        this._alarmVisible     = false;
        this._lastBubbleTick   = GLib.get_monotonic_time();
        this._inRemoval        = false;
        this._chameleonIndex   = 0;
        this._chameleonT       = 0;
        this._chameleonSource  = null;
        this._chameleonCurrent = MACOS_PALETTE[0];
        this._sizeDebounce     = null;
        this._utBubbles        = [];
    },

    on_desklet_added_to_desktop: function(_ue) {
        // Force defaults for existing instances whose config predates these settings
        if (this.magicMode      === false) this.magicMode      = true;
        if (this.rainbowBubbles === false) this.rainbowBubbles = true;
        this._buildUI();
        this._initBubbles();
        this._startClocks();
        this._startBubbleAnimation();
        this._applyDecorations();
        this._startChameleon();
        if (!this.chameleonMode) this._stopChameleon();
        if (this.ubuntuTouchMode) this._initUTBubbles();
    },

    // ── Helpers ───────────────────────────────────────────────────────────
    _effectiveColor: function() {
        return this.chameleonMode ? this._chameleonCurrent : (this.themeColor || CLASSIC_COLOR);
    },
    _invalidateBg:   function() { if (this._bgCanvas)   this._bgCanvas.invalidate();   },
    _invalidateRing: function() { if (this._ringCanvas) this._ringCanvas.invalidate(); },

    // Returns a CSS rgba() string for text.
    // settingVal: value from colorchooser (hex or rgba string).
    // "#000000" is the sentinel meaning "auto-tint from background".
    // alpha: 0–1 final opacity for the returned color.
    _resolveTextColor: function(settingVal, alpha) {
        const isAuto = !settingVal
            || settingVal.trim() === ""
            || settingVal.trim().toLowerCase() === "#000000"
            || settingVal.trim().toLowerCase() === "rgba(0,0,0,1)"
            || settingVal.trim().toLowerCase() === "rgba(0, 0, 0, 1)";
        let rgb;
        if (isAuto) {
            rgb = tintRGB(hexToRGB(this._effectiveColor()), 0.85);
        } else {
            rgb = hexToRGB(settingVal);
        }
        return `rgba(${Math.round(rgb[0]*255)},${Math.round(rgb[1]*255)},${Math.round(rgb[2]*255)},${alpha})`;
    },

    // ── Clock style (pure CSS, no Clutter.Text methods) ───────────────────
    _applyClockStyle: function() {
        if (!this._clockLabel) return;
        const sz  = this.clockSize || 220;
        const fs  = Math.round(sz * 0.18);
        const ff  = (this.fontFamily && this.fontFamily.trim() !== "")
                    ? this.fontFamily.trim() : "Cantarell";
        const clr = this._resolveTextColor(this.clockTextColor, 0.97);
        this._clockLabel.set_style(`font-family:"${ff}"; font-size:${fs}px; color:${clr};`);
    },

    // ── UI ────────────────────────────────────────────────────────────────
    _buildUI: function() {
        const sz = this.clockSize;

        // Magic mode: no clipping so bubbles can float outside the circle
        // clip_to_allocation is always false — we rely on Cairo's clipCircle()
        // in _drawBackground and _drawRing for the circular shape.
        // clip_to_allocation:true would clip children rectangularly anyway
        // (border-radius is not respected for child clipping in Muffin/Clutter).
        this._root = new St.Widget({
            width: sz, height: sz,
            style: `border-radius:${Math.round(sz/2)}px;`,
            clip_to_allocation: false,
            reactive: true
        });

        // Background + bubbles canvas
        // In magic mode this canvas is bigger than the desklet so escaping
        // bubbles have room to be drawn. We extend it by MAGIC_FADE_DIST above.
        this._bgCanvas = new Clutter.Canvas();
        this._bgCanvas.set_size(sz, sz);
        this._bgCanvas.connect("draw", (_c,cr,w,h) => { this._drawBackground(cr,w,h); return true; });
        this._bgActor = new Clutter.Actor({ width:sz, height:sz });
        this._bgActor.set_content(this._bgCanvas);
        this._root.add_actor(this._bgActor);

        // Ring canvas
        this._ringCanvas = new Clutter.Canvas();
        this._ringCanvas.set_size(sz, sz);
        this._ringCanvas.connect("draw", (_c,cr,w,h) => { this._drawRing(cr,w,h); return true; });
        this._ringActor = new Clutter.Actor({ width:sz, height:sz });
        this._ringActor.set_content(this._ringCanvas);
        this._root.add_actor(this._ringActor);

        // Magic overlay canvas — sits above root, draws escaping bubbles
        // It is a sibling of root, but we fake that by drawing them in a
        // separate actor positioned so y=0 aligns with the desklet top.
        this._magicCanvas = new Clutter.Canvas();
        this._magicCanvas.set_size(sz + MAGIC_FADE_DIST*2, sz + MAGIC_FADE_DIST);
        this._magicCanvas.connect("draw", (_c,cr,w,h) => { this._drawMagicBubbles(cr,w,h); return true; });
        this._magicActor = new Clutter.Actor({
            width:  sz + MAGIC_FADE_DIST*2,
            height: sz + MAGIC_FADE_DIST,
            visible: !!this.magicMode
        });
        this._magicActor.set_content(this._magicCanvas);
        // Position so the desklet circle maps to the bottom portion of this canvas
        this._magicActor.set_position(-(MAGIC_FADE_DIST), -MAGIC_FADE_DIST);
        this._root.add_actor(this._magicActor);

        // Clock label in St.Bin
        this._clockLabel = new St.Label({ text: "" });
        this._applyClockStyle();
        this._clockBin = new St.Bin({
            width: sz, height: sz,
            x_align: St.Align.MIDDLE,
            y_align: St.Align.MIDDLE,
            child: this._clockLabel
        });
        this._clockBin.set_position(0, 0);
        this._root.add_actor(this._clockBin);

        // Timer label
        this._timerLabel = new St.Label({
            text: "",
            style: "font-size:13px; color:rgba(255,255,255,0.7);"
        });
        this._timerLabel.set_position(sz/2 - 60, sz - 26);
        this._root.add_actor(this._timerLabel);

        // Date label — inside the circle, centred horizontally, below clock text
        // Positioned at ~65% down the circle so it sits clearly under the time
        this._dateLabel = new St.Label({ text: "" });
        this._dateBin = new St.Bin({
            width: sz,
            height: Math.round(sz * 0.18),
            x_align: St.Align.MIDDLE,
            y_align: St.Align.MIDDLE,
            child: this._dateLabel
        });
        this._dateBin.set_position(0, Math.round(sz * 0.57));
        this._root.add_actor(this._dateBin);
        this._updateDateLabel();

        this._buildAlarmOverlay(sz);

        this.setContent(this._root);
        this.setHeader(_("Clepsydra"));
        this._updateRootOpacity();
        this._bgCanvas.invalidate();
        this._ringCanvas.invalidate();
    },

    _buildAlarmOverlay: function(sz) {
        this._alarmOverlay = new St.Widget({ width:sz, height:sz, visible:false,
            style: "background-color:rgba(47,9,22,0.97);" });
        this._alarmTitle = new St.Label({ text: "Time's Up!",
            style: "font-size:28px; color:white; font-weight:bold;" });
        this._alarmTitle.set_position(sz*0.1, sz*0.18);
        this._alarmCloseBtn = new St.Button({ label: "Close",
            style: "background-color:rgba(255,255,255,0.25); color:white;" +
                   "border-radius:6px; padding:6px 18px; font-size:15px;" });
        this._alarmCloseBtn.set_position(sz/2-50, sz*0.72);
        this._alarmCloseBtn.connect("clicked", () => this._dismissAlarm());
        this._alarmIconCanvas = new Clutter.Canvas();
        this._alarmIconCanvas.set_size(80, 80);
        this._alarmIconCanvas.connect("draw", (_c,cr,w,h) => { this._drawAlarmIcon(cr,w,h); return true; });
        this._alarmIconActor = new Clutter.Actor({ width:80, height:80 });
        this._alarmIconActor.set_content(this._alarmIconCanvas);
        this._alarmIconActor.set_position(sz/2-40, sz*0.36);
        this._alarmOverlay.add_actor(this._alarmTitle);
        this._alarmOverlay.add_actor(this._alarmIconActor);
        this._alarmOverlay.add_actor(this._alarmCloseBtn);
        this._root.add_actor(this._alarmOverlay);
    },

    // ── Draw background (bubbles inside desklet) ──────────────────────────
    _drawBackground: function(cr, w, h) {
        cr.setOperator(Cairo.Operator.CLEAR); cr.paint();
        cr.setOperator(Cairo.Operator.OVER);

        // ALWAYS clip to circle — this is what makes the desklet round.
        // Magic mode escaping bubbles are drawn on a separate canvas (magicActor)
        // that lives outside the clipped area, so they can bleed onto the desktop.
        clipCircle(cr, w, h);

        const bgRGB = hexToRGB(this._effectiveColor());
        cr.setSourceRGB(bgRGB[0], bgRGB[1], bgRGB[2]);
        cr.rectangle(0, 0, w, h); cr.fill();

        // Ubuntu Touch mode replaces normal bubbles with radial UT bubbles
        if (this.ubuntuTouchMode) {
            this._drawUbuntuTouchOverlay(cr, w, h);
            return;
        }

        const cx = w / 2, cy = h / 2, circR = Math.min(w, h) / 2;

        for (const b of this._bubbles) {
            if (b.y < 0) continue;  // escaped — drawn on magicCanvas
            let alphaMult = 1.0;
            if (this.magicMode) {
                // Fade bubbles as they approach the top of the circle so there is
                // no hard clip-edge seam when they cross into the magic canvas.
                // Use distance from bubble centre to circle edge along the upward
                // path: when the bubble is within its own radius of the top rim,
                // start fading to 0 at the boundary.
                const distFromCenter = Math.sqrt((b.x - cx) * (b.x - cx) + (b.y - cy) * (b.y - cy));
                const distToEdge = circR - distFromCenter;   // how far from the rim (px)
                const fadeZone = b.r * 2.5;                  // start fading 2.5 radii before the rim
                if (distToEdge < fadeZone) {
                    alphaMult = Math.max(0, distToEdge / fadeZone);
                }
            }
            this._drawOneBubble(cr, b, bgRGB, alphaMult);
        }
    },

    // ── Draw escaping bubbles (magic canvas, coordinate-shifted) ─────────
    _drawMagicBubbles: function(cr, w, h) {
        cr.setOperator(Cairo.Operator.CLEAR); cr.paint();
        cr.setOperator(Cairo.Operator.OVER);

        const bgRGB = hexToRGB(this._effectiveColor());
        const sz    = this.clockSize;
        const offX  = MAGIC_FADE_DIST;   // canvas left edge is MAGIC_FADE_DIST left of desklet
        const offY  = MAGIC_FADE_DIST;   // canvas top edge is MAGIC_FADE_DIST above desklet

        for (const b of this._bubbles) {
            if (b.y >= 0) continue;  // still inside — drawn in background canvas
            // magicFade: 1.0 just above circle → 0.0 at MAGIC_FADE_DIST above
            const distAbove = -b.y;   // positive: how far above the circle top (y=0)
            // Use a smooth ease-in curve so bubbles start nearly invisible right
            // at the rim and reach full fade-rate quickly — eliminates the seam.
            const t = Math.min(1, distAbove / MAGIC_FADE_DIST);
            const fade = 1 - t * t;   // quadratic ease-out: fast fade after rim
            if (fade <= 0.01) continue;
            const cx = b.x + offX;
            const cy = b.y + offY;
            this._drawOneBubble(cr, b, bgRGB, fade, cx, cy);
        }
    },

    // ── Single bubble draw (shared by both canvases) ──────────────────────
    _drawOneBubble: function(cr, b, bgRGB, alphaMult, cx, cy) {
        // Use b.x/b.y unless override coords provided (magic canvas)
        const bx = (cx !== undefined) ? cx : b.x;
        const by = (cy !== undefined) ? cy : b.y;
        const alpha = b.alpha * alphaMult;

        // Choose colour
        let bRGB;
        if (this.rainbowBubbles) {
            bRGB = b.rainbowRGB();
        } else {
            const bHex = this.bubbleColor || "#ffffff";
            bRGB = bHex.toLowerCase() === "#ffffff" ? tintRGB(bgRGB, 0.55) : hexToRGB(bHex);
        }

        if (this.frostedBubbles) {
            // ── Frosted-glass / liquid-glass look ────────────────────────
            // Layer 1: translucent fill (base tint)
            cr.setSourceRGBA(bRGB[0], bRGB[1], bRGB[2], alpha * 0.25);
            cr.arc(bx, by, b.r, 0, 2*Math.PI); cr.fill();

            // Layer 2: radial gradient — bright rim fading to transparent centre
            try {
                const grad = new Cairo.RadialGradient(bx, by, b.r*0.3, bx, by, b.r);
                grad.addColorStopRGBA(0, bRGB[0], bRGB[1], bRGB[2], alpha * 0.05);
                grad.addColorStopRGBA(0.6, bRGB[0], bRGB[1], bRGB[2], alpha * 0.18);
                grad.addColorStopRGBA(1,   bRGB[0], bRGB[1], bRGB[2], alpha * 0.55);
                cr.setSource(grad);
                cr.arc(bx, by, b.r, 0, 2*Math.PI); cr.fill();
            } catch(e) {}

            // Layer 3: white rim highlight (thin outer ring)
            cr.setSourceRGBA(1, 1, 1, alpha * 0.45);
            cr.setLineWidth(1.2);
            cr.arc(bx, by, b.r - 0.8, 0, 2*Math.PI); cr.stroke();

            // Layer 4: specular glint (top-left crescent, macOS liquid-glass style)
            try {
                const gx = bx - b.r*0.28, gy = by - b.r*0.32;
                const specR = b.r * 0.52;
                const sgrad = new Cairo.RadialGradient(gx, gy, 0, gx, gy, specR);
                sgrad.addColorStopRGBA(0,   1, 1, 1, alpha * 0.72);
                sgrad.addColorStopRGBA(0.4, 1, 1, 1, alpha * 0.28);
                sgrad.addColorStopRGBA(1,   1, 1, 1, 0);
                cr.setSource(sgrad);
                cr.arc(bx, by, b.r, 0, 2*Math.PI); cr.fill();
            } catch(e) {}

        } else {
            // ── Standard solid bubble ─────────────────────────────────────
            cr.setSourceRGBA(bRGB[0], bRGB[1], bRGB[2], alpha);
            cr.arc(bx, by, b.r, 0, 2*Math.PI); cr.fill();
            // Inner highlight
            cr.setSourceRGBA(1, 1, 1, alpha * 0.35);
            cr.arc(bx - b.r*0.28, by - b.r*0.28, b.r*0.38, 0, 2*Math.PI); cr.fill();
        }
    },

    // ── Ubuntu Touch mode ─────────────────────────────────────────────────────
    _initUTBubbles: function() {
        this._utBubbles = [];
        const sz = this.clockSize;
        for (let i = 0; i < UT_BUBBLE_COUNT; i++) {
            const b = new UTBubble(sz, i);
            b.life = i / UT_BUBBLE_COUNT;
            b.x = sz/2 + Math.cos(b.angle) * sz * 0.18 * b.life;
            b.y = sz/2 + Math.sin(b.angle) * sz * 0.18 * b.life;
            this._utBubbles.push(b);
        }
    },

    _onUbuntuTouchChanged: function() {
        if (this.ubuntuTouchMode) this._initUTBubbles();
        else this._utBubbles = [];
        this._invalidateBg();
    },

    _drawUbuntuTouchOverlay: function(cr, w, h) {
        const cx = w/2, cy = h/2, radius = Math.min(w,h)/2;
        // Dark smoky overlay — the "glass circle" from the Ubuntu Touch screenshot
        cr.setSourceRGBA(0.06, 0.01, 0.09, 0.70);
        cr.arc(cx, cy, radius, 0, 2*Math.PI); cr.fill();
        // Radial colour blobs radiating outward
        for (const b of this._utBubbles) {
            const fa = b.fadeAlpha();
            if (fa <= 0.01) continue;
            const rgb = b.colour();
            try {
                const grad = new Cairo.RadialGradient(b.x, b.y, 0, b.x, b.y, b.r);
                grad.addColorStopRGBA(0,   rgb[0], rgb[1], rgb[2], fa * 0.85);
                grad.addColorStopRGBA(0.5, rgb[0], rgb[1], rgb[2], fa * 0.42);
                grad.addColorStopRGBA(1,   rgb[0], rgb[1], rgb[2], 0);
                cr.setSource(grad);
                cr.arc(b.x, b.y, b.r, 0, 2*Math.PI); cr.fill();
            } catch(e) {
                cr.setSourceRGBA(rgb[0], rgb[1], rgb[2], fa*0.5);
                cr.arc(b.x, b.y, b.r, 0, 2*Math.PI); cr.fill();
            }
            cr.setSourceRGBA(1, 1, 1, fa * 0.16);
            cr.arc(b.x - b.r*0.25, b.y - b.r*0.28, b.r*0.32, 0, 2*Math.PI); cr.fill();
        }
    },

    // ── Draw ring ─────────────────────────────────────────────────────────
    _drawRing: function(cr, w, h) {
        cr.setOperator(Cairo.Operator.CLEAR); cr.paint();
        cr.setOperator(Cairo.Operator.OVER);
        // Always clip to circle
        clipCircle(cr, w, h);
        const seconds = new Date().getSeconds();
        const cx = w/2, cy = h/2;
        const ringR = Math.min(w,h)/2 - RING_PAD - DOT_R;
        const dRGB  = hexToRGB(this.dotColor || "#ffffff");
        for (let i = 0; i < DOT_COUNT; i++) {
            const angle = (i/DOT_COUNT)*2*Math.PI - Math.PI/2;
            const dx = cx + ringR*Math.cos(angle);
            const dy = cy + ringR*Math.sin(angle);
            cr.setSourceRGBA(dRGB[0], dRGB[1], dRGB[2], i <= seconds ? 0.88 : 0.22);
            cr.arc(dx, dy, DOT_R, 0, 2*Math.PI); cr.fill();
        }
    },

    _drawAlarmIcon: function(cr, w, h) {
        cr.setOperator(Cairo.Operator.CLEAR); cr.paint();
        cr.setOperator(Cairo.Operator.OVER);
        const s = w/24, rgb = hexToRGB(this._effectiveColor());
        cr.setSourceRGBA(1,1,1,0.9);
        cr.arc(w/2,h/2+s,9*s,0,2*Math.PI); cr.fill();
        cr.setSourceRGBA(rgb[0],rgb[1],rgb[2],1);
        cr.arc(w/2,h/2+s,7.5*s,0,2*Math.PI); cr.fill();
        cr.setSourceRGBA(1,1,1,0.9); cr.setLineWidth(1.2*s);
        cr.moveTo(w/2,h/2+s); cr.lineTo(w/2,h/2-3*s); cr.stroke();
        cr.moveTo(w/2,h/2+s); cr.lineTo(w/2+3*s,h/2+s); cr.stroke();
        cr.arc(w/2-5*s,h/2-5*s,2.5*s,0,2*Math.PI); cr.fill();
        cr.arc(w/2+5*s,h/2-5*s,2.5*s,0,2*Math.PI); cr.fill();
    },

    // ── Bubbles ───────────────────────────────────────────────────────────
    _initBubbles: function() {
        this._bubbles = [];
        const sz = this.clockSize;
        for (let i = 0; i < BUBBLE_COUNT; i++) {
            const b = new Bubble(sz, i);
            b.y = Math.random() * sz;
            this._bubbles.push(b);
        }
    },

    _startBubbleAnimation: function() {
        if (this._bubbleSource) { source_remove(this._bubbleSource); this._bubbleSource = null; }
        this._bubbleSource = timeout_add(40, () => {
            if (this._inRemoval) return false;
            const now = GLib.get_monotonic_time();
            const dt  = (now - this._lastBubbleTick) / 40000;
            this._lastBubbleTick = now;
            for (const b of this._bubbles) b.tick(this.clockSize, dt, this.magicMode);
            if (this.ubuntuTouchMode) { for (const b of this._utBubbles) b.tick(this.clockSize, dt); }
            this._invalidateBg();
            if (this.magicMode && this._magicCanvas) this._magicCanvas.invalidate();
            return true;
        });
    },

    // ── Clock ─────────────────────────────────────────────────────────────
    _startClocks: function() {
        if (this._clockSource) { source_remove(this._clockSource); this._clockSource = null; }
        this._updateClock();
        this._clockSource = timeout_add(500, () => {
            if (this._inRemoval) return false;
            this._updateClock(); return true;
        });
    },

    _updateClock: function() {
        if (!this._clockLabel) return;
        const now = new Date(), pad = n => String(n).padStart(2,"0");
        let text;
        if (this.use24h) {
            text = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
        } else {
            let h = now.getHours(); const ampm = h >= 12 ? "PM" : "AM"; h = h%12||12;
            text = `${pad(h)}:${pad(now.getMinutes())}:${pad(now.getSeconds())} ${ampm}`;
        }
        if (!this.showSeconds) text = text.replace(/:\d{2}(\s|$)/, "$1").trim();
        this._clockLabel.set_text(text);
        this._updateDateLabel();
        this._invalidateRing();
    },

    // ── Date label ────────────────────────────────────────────────────────
    _updateDateLabel: function() {
        if (!this._dateLabel || !this._dateBin) return;
        if (!this.showDate) {
            this._dateBin.hide();
            return;
        }
        this._dateBin.show();
        const now = new Date();
        const days   = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
        const months = ["January","February","March","April","May","June",
                        "July","August","September","October","November","December"];
        const dateText = `${days[now.getDay()]}, ${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
        this._dateLabel.set_text(dateText);

        const sz  = this.clockSize || 220;
        const fs  = Math.round(sz * 0.072);   // ~40% of clock font — clearly smaller
        const ff  = (this.dateFontFamily && this.dateFontFamily.trim() !== "")
                    ? this.dateFontFamily.trim()
                    : ((this.fontFamily && this.fontFamily.trim() !== "") ? this.fontFamily.trim() : "Cantarell");
        const clr = this._resolveTextColor(this.dateTextColor, 0.88);
        this._dateLabel.set_style(`font-family:"${ff}"; font-size:${fs}px; color:${clr};`);
    },

    // ── Chameleon ─────────────────────────────────────────────────────────
    _startChameleon: function() {
        if (this._chameleonSource) { source_remove(this._chameleonSource); this._chameleonSource = null; }
        this._chameleonIndex   = 0;
        this._chameleonT       = 0;
        this._chameleonCurrent = MACOS_PALETTE[0];
        this._chameleonSource  = timeout_add(40, () => {
            if (this._inRemoval) return false;
            this._chameleonT += 0.013;
            if (this._chameleonT >= 1) {
                this._chameleonT = 0;
                this._chameleonIndex = (this._chameleonIndex + 1) % MACOS_PALETTE.length;
            }
            const a = MACOS_PALETTE[this._chameleonIndex];
            const b = MACOS_PALETTE[(this._chameleonIndex+1) % MACOS_PALETTE.length];
            this._chameleonCurrent = lerpHex(a, b, this._chameleonT);
            this._applyClockStyle();
            this._updateDateLabel();
            return true;
        });
    },

    _stopChameleon: function() {
        if (this._chameleonSource) { source_remove(this._chameleonSource); this._chameleonSource = null; }
    },

    _onChameleonChanged: function() {
        if (this.chameleonMode) {
            this._startChameleon();
        } else {
            this._stopChameleon();
            this._chameleonCurrent = this.themeColor || CLASSIC_COLOR;
            this._applyClockStyle();
            this._invalidateBg();
            this._invalidateRing();
        }
    },

    // ── Magic mode ────────────────────────────────────────────────────────
    _onMagicChanged: function() {
        if (!this._root) return;
        // clip_to_allocation cannot be changed after construction without rebuild
        // so we do a lightweight rebuild
        this._rebuild();
    },

    _rebuild: function() {
        if (!this._root) return;
        // Stop timers temporarily
        if (this._bubbleSource) { source_remove(this._bubbleSource); this._bubbleSource = null; }
        if (this._clockSource)  { source_remove(this._clockSource);  this._clockSource  = null; }
        // Remove old content
        this.setContent(null);
        // Rebuild
        this._buildUI();
        this._startClocks();
        this._startBubbleAnimation();
        if (this.chameleonMode) this._startChameleon();
        if (this.ubuntuTouchMode) this._initUTBubbles();
    },

    // ── Decorations ───────────────────────────────────────────────────────
    _applyDecorations: function() {
        try {
            this.metadata["prevent-decorations"] = !!this.hideDecorations;
            if (typeof this.setDecorated === "function")
                this.setDecorated(!this.hideDecorations);
        } catch(e) {}
    },

    // ── Settings handlers ─────────────────────────────────────────────────
    _onThemeChanged: function() {
        if (!this.chameleonMode) this._chameleonCurrent = this.themeColor || CLASSIC_COLOR;
        this._applyClockStyle();
        this._updateDateLabel();
        this._invalidateBg();
        this._invalidateRing();
    },

    _scheduleSizeChange: function() {
        if (this._sizeDebounce) { source_remove(this._sizeDebounce); this._sizeDebounce = null; }
        this._sizeDebounce = timeout_add(120, () => {
            this._sizeDebounce = null;
            this._onSizeChanged();
            return false;
        });
    },

    _onSizeChanged: function() {
        if (!this._root) return;
        const sz = this.clockSize;
        const mw = sz + MAGIC_FADE_DIST*2;
        const mh = sz + MAGIC_FADE_DIST;

        this._root.set_style(`border-radius:${Math.round(sz/2)}px;`);
        this._root.set_size(sz, sz);

        this._bgCanvas.set_size(sz, sz);   this._bgActor.set_size(sz, sz);
        this._ringCanvas.set_size(sz, sz); this._ringActor.set_size(sz, sz);

        this._magicCanvas.set_size(mw, mh);
        this._magicActor.set_size(mw, mh);
        this._magicActor.set_position(-MAGIC_FADE_DIST, -MAGIC_FADE_DIST);

        this._clockBin.set_size(sz, sz);
        this._alarmOverlay.set_size(sz, sz);
        this._alarmTitle.set_position(sz*0.1, sz*0.18);
        this._alarmCloseBtn.set_position(sz/2-50, sz*0.72);
        this._alarmIconActor.set_position(sz/2-40, sz*0.36);
        this._timerLabel.set_position(sz/2-60, sz-26);

        // Reposition and resize date bin — inside circle, below clock text
        if (this._dateBin) {
            this._dateBin.set_size(sz, Math.round(sz * 0.18));
            this._dateBin.set_position(0, Math.round(sz * 0.57));
        }

        this._applyClockStyle();
        this._updateDateLabel();
        this._initBubbles();
        if (this.ubuntuTouchMode) this._initUTBubbles();
        this._invalidateBg();
        this._invalidateRing();
        if (this.magicMode) this._magicCanvas.invalidate();
    },

    _updateRootOpacity: function() {
        if (!this._bgActor && !this._ringActor) return;
        // Opacity applies only to the background (bubbles) and magic overlay.
        // Clock text (_clockBin), date label (_dateBin), and ring dots (_ringActor)
        // always stay fully opaque so they remain legible regardless of the slider.
        const v = Math.round(Math.max(0.05, Math.min(1, this.clockOpacity)) * 255);
        if (this._bgActor)    this._bgActor.set_opacity(v);
        if (this._magicActor) this._magicActor.set_opacity(v);
        // _ringActor and _clockBin intentionally NOT touched — always opaque.
    },

    // ── Timer ─────────────────────────────────────────────────────────────
    startTimer: function(totalSeconds) {
        if (this._timerSource) { source_remove(this._timerSource); this._timerSource = null; }
        this._timerRemaining = totalSeconds; this._timerActive = true;
        this._timerLabel.set_text(this._formatTimer(totalSeconds));
        this._timerSource = timeout_add(1000, () => {
            if (this._inRemoval || !this._timerActive) return false;
            if (--this._timerRemaining <= 0) {
                this._timerActive = false; this._timerLabel.set_text(""); this._triggerAlarm(); return false;
            }
            this._timerLabel.set_text(this._formatTimer(this._timerRemaining)); return true;
        });
    },

    _formatTimer: function(s) {
        const h=Math.floor(s/3600), m=Math.floor((s%3600)/60), sec=s%60;
        const pad=n=>String(n).padStart(2,"0");
        return h>0 ? `Timer: ${pad(h)}:${pad(m)}:${pad(sec)}` : `Timer: ${pad(m)}:${pad(sec)}`;
    },

    _triggerAlarm: function() {
        this._alarmVisible = true;
        if (this._alarmOverlay) this._alarmOverlay.show();
        if (this._alarmIconCanvas) this._alarmIconCanvas.invalidate();
        try {
            let f = Gio.file_new_for_path("/usr/share/sounds/freedesktop/stereo/alarm-clock-elapsed.oga");
            if (!f.query_exists(null)) f = Gio.file_new_for_path("/usr/share/sounds/ubuntu/stereo/phone-incoming-call.ogg");
            if (f.query_exists(null)) imports.misc.util.spawnCommandLine("paplay "+f.get_path());
        } catch(e) {}
        try { imports.misc.util.spawnCommandLine('notify-send "Clepsydra" "Timer finished!" -i clock -t 8000'); } catch(e) {}
    },

    _dismissAlarm: function() {
        this._alarmVisible = false;
        if (this._alarmOverlay) this._alarmOverlay.hide();
    },

    on_desklet_removed: function(_d) {
        this._inRemoval = true;
        if (this._clockSource)     source_remove(this._clockSource);
        if (this._bubbleSource)    source_remove(this._bubbleSource);
        if (this._timerSource)     source_remove(this._timerSource);
        if (this._chameleonSource) source_remove(this._chameleonSource);
        if (this._sizeDebounce)    source_remove(this._sizeDebounce);
        remove_all_sources();
        this._signalManager.disconnectAllSignals();
    }
};

function main(metadata, instanceId) { return new ClepsydraDesklet(metadata, instanceId); }
