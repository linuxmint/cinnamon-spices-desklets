cp -r ./files/daily-agenda@alexmakessoftware ~/.local/share/cinnamon/desklets/
