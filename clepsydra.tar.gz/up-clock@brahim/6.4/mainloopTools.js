const GLib = imports.gi.GLib;

var _sourceIds = [];

function timeout_add_seconds(sec, callback, params=null) {
  let id = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, sec, callback);
  if (id && (_sourceIds.indexOf(id) === -1)) _sourceIds.push(id);
  return id;
}

function timeout_add(ms, callback, params=null) {
  let id = GLib.timeout_add(GLib.PRIORITY_DEFAULT, ms, callback);
  if (id && (_sourceIds.indexOf(id) === -1)) _sourceIds.push(id);
  return id;
}

function setTimeout(callback, ms) {
    let args = [];
    if (arguments.length > 2) {
        args = args.slice.call(arguments, 2);
    }
    let id = GLib.timeout_add(GLib.PRIORITY_DEFAULT, ms, () => {
        callback.call(null, ...args);
        return false;
    });
    if (id && (_sourceIds.indexOf(id) === -1)) _sourceIds.push(id);
    return id;
}

function clearTimeout(id) {
    if (id) { source_remove(id); }
}

function setInterval(callback, ms) {
    let args = [];
    if (arguments.length > 2) {
        args = args.slice.call(arguments, 2);
    }
    let id = GLib.timeout_add(GLib.PRIORITY_DEFAULT, ms, () => {
        callback.call(null, ...args);
        return true;
    });
    if (id && (_sourceIds.indexOf(id) === -1)) _sourceIds.push(id);
    return id;
}

function clearInterval(id) {
    if (id) { source_remove(id); }
}

function source_exists(id) {
    let _id = id;
    if (!_id) return false;
    return (GLib.MainContext.default().find_source_by_id(_id) != null);
}

function source_remove(id, remove_from_sourceIds=true) {
    if (source_exists(id)) {
        GLib.source_remove(id);
        if (remove_from_sourceIds) {
            const pos = _sourceIds.indexOf(id);
            if (pos > -1) _sourceIds.splice(pos, 1);
        }
        return true;
    }
    return false;
}

function remove_all_sources() {
    while (_sourceIds.length > 0) {
        let id = _sourceIds.pop();
        source_remove(id, false);
    }
}

module.exports = {
    _sourceIds,
    timeout_add_seconds,
    timeout_add,
    setTimeout,
    clearTimeout,
    setInterval,
    clearInterval,
    source_exists,
    source_remove,
    remove_all_sources
}
